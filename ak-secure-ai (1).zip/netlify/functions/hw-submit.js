// विद्यार्थ्याचा गृहपाठ फोटो जमा करणे (वर्ग + हजेरी क्र. + PIN) / स्थिती पाहणे
const { get, set, query, authStudent, istToday, J, parse } = require('./lib/fb');
const MAX_TOTAL = 900000, JPEG = 'data:image/jpeg;base64,';

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return J(405, { error: 'POST हवे' });
  if (!process.env.FIREBASE_SERVICE_ACCOUNT) return J(500, { error: 'सेवा अजून सुरू केलेली नाही (FIREBASE_SERVICE_ACCOUNT).' });
  const b = parse(event); if (!b) return J(400, { error: 'चुकीची विनंती.' });
  try {
    const a = await authStudent(b.classKey, b.roll, b.pin);
    if (a.err) return J(a.code, { error: a.err });
    if (b.action === 'list') { // विद्यार्थी विभाग: या विद्यार्थ्याची सर्व गृहपाठ स्थिती
      const ps = await query('hwPhotos', { classKey: b.classKey, studentId: a.s.id }, 200), items = {};
      ps.forEach(x => { items[x.hwId] = { status: x.status, score: x.status === 'approved' ? x.finalScore : x.aiScore, max: x.aiMax || 0, final: x.status === 'approved', feedback: x.aiFeedback || '', note: x.teacherNote || '' }; });
      return J(200, { name: a.s.name, roll: a.s.roll, items });
    }
    const s = a.s, hwId = String(b.hwId || '').replace(/[^A-Za-z0-9]/g, '').slice(0, 40);
    if (!hwId) return J(400, { error: 'गृहपाठ निवडा.' });
    const hw = await get('homework/' + hwId);
    if (!hw || hw.classKey !== b.classKey || !hw.photo) return J(404, { error: 'हा गृहपाठ फोटोने सादर करण्यासाठी नाही.' });
    const id = hwId + '_' + s.id, old = await get('hwPhotos/' + id);

    if (b.action === 'status') {
      if (!old) return J(200, { submitted: false, name: s.name });
      const fin = old.status === 'approved';
      return J(200, { submitted: true, name: s.name, status: old.status, score: fin ? old.finalScore : old.aiScore, max: old.aiMax || hw.maxMarks || 0, final: fin, feedback: old.aiFeedback || '', note: old.teacherNote || '' });
    }

    const imgs = Array.isArray(b.images) ? b.images.slice(0, 3) : [];
    if (!imgs.length || imgs.some(x => typeof x !== 'string' || !x.startsWith(JPEG))) return J(400, { error: 'किमान १ फोटो (JPG) निवडा.' });
    if (imgs.some(x => Buffer.from(x.slice(JPEG.length, JPEG.length + 8), 'base64').toString('hex').slice(0, 6) !== 'ffd8ff')) return J(400, { error: 'फक्त खरे फोटो (JPG) चालतात.' });
    if (imgs.join('').length > MAX_TOTAL) return J(413, { error: 'फोटो खूप मोठे आहेत. कमी फोटो किंवा जवळून काढलेला फोटो वापरा.' });
    if (old && old.status === 'approved') return J(409, { error: 'हा गृहपाठ शिक्षकांनी तपासून अंतिम केला आहे.' });
    if (old && (old.attempts || 0) >= 3) return J(429, { error: 'जास्तीत जास्त ३ वेळा पाठवता येते. वर्गशिक्षकांना भेटा.' });
    const now = Date.now();
    await set('hwImages/' + id, { classKey: b.classKey, hwId, studentId: s.id, images: imgs, updatedAt: now });
    await set('hwPhotos/' + id, { hwId, classKey: b.classKey, studentId: s.id, roll: s.roll, name: s.name, status: 'pending', attempts: ((old && old.attempts) || 0) + 1,
      late: !!(hw.due && istToday() > hw.due), pages: imgs.length, createdAt: (old && old.createdAt) || now, updatedAt: now, aiScore: null, aiMax: hw.maxMarks || 10, aiFeedback: '', finalScore: null });
    return J(200, { ok: true, name: s.name });
  } catch (e) { console.error(e); return J(500, { error: 'सेवा तात्पुरती चालत नाही. थोड्या वेळाने प्रयत्न करा.' }); }
};

// एका विद्यार्थ्याचा नवा PIN बनवणे (admin किंवा त्या वर्गाचा शिक्षक); जुना PIN व लॉक लगेच साफ
const crypto = require('crypto');
const { get, set, patch, teacherClasses, J, parse, bearer } = require('./lib/fb');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return J(405, { error: 'POST हवे' });
  if (!process.env.FIREBASE_SERVICE_ACCOUNT) return J(500, { error: 'सेवा अजून सुरू केलेली नाही.' });
  const b = parse(event); if (!b) return J(400, { error: 'चुकीची विनंती.' });
  try {
    const t = await teacherClasses(bearer(event));
    if (!t) return J(403, { error: 'परवानगी नाही.' });
    const id = String(b.studentId || '').replace(/[^A-Za-z0-9]/g, '').slice(0, 40);
    if (!id) return J(400, { error: 'विद्यार्थी निवडा.' });
    const s = await get('students/' + id);
    if (!s) return J(404, { error: 'विद्यार्थी सापडला नाही.' });
    if (!t.all && !t.classes.includes(s.classKey)) return J(403, { error: 'हा वर्ग तुमचा नाही.' });
    const pin = String(crypto.randomInt(1000, 10000));
    await patch('students/' + id, { pin, pinResetAt: Date.now(), updatedAt: Date.now() });
    await set('pinLocks/' + id, { fails: 0, until: 0 });
    return J(200, { pin, name: s.name, roll: s.roll, classKey: s.classKey });
  } catch (e) { console.error(e); return J(500, { error: 'सेवा तात्पुरती चालत नाही.' }); }
};
